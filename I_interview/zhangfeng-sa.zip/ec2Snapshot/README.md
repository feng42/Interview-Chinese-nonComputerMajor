# Build EC2 Snapshot From Local HTML
- linux版本:ubuntu 16.04
- 已安装nodejs
- 已安装AWS-CLI
1. 在Linux终端执行：
node ec2new.js
建立服务端，访问地址为http://127.0.0.1:8087/index.htm
<img/buildWeb.png>
2. 进入访问地址http://127.0.0.1:8087/index.htm，对话框可输入需要进行建立对应快照的卷名，点击Submit提交
<img/submit.png>
3. 点击submit后，服务端调用子进程，使用aws-cli命令控制远程的ec2建立快照，在终端中会显示指令和子进程的输出结果
<img/shell-aws.png>
4. 于此同时，可以在html网页中看到shell的输出结果，输出结果用JSON记录
<img/htmlJSON.png>
5. 另一方面，在AWS的EC2控制台可以看到正在建立的ec2快照，因为尚未完成，状态显示为pengding
<img/ec2pending>
