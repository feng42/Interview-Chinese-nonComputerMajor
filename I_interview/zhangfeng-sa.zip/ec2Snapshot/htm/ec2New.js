var express = require('express');
var app = express();
 
app.use(express.static('public'));
 
app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "ec2New.html" );
})
 
app.get('/process_get', function (req, res) {
 
   // 输出 JSON 格式
    var volId=req.query.volume_id;
    var exec = require('child_process').exec; 
	var cmdStr = 'aws ec2 create-snapshot --volume-id '+volId+' --description "NEW Snap FROM HTML"';
    console.log("指令：　"+cmdStr);
	exec(cmdStr, function(err,stdout,stderr){
        if(err) {
            console.log('create snapshot api error:'+stderr);
        } else {
            var Cdata = JSON.parse(stdout);
            console.log(Cdata);
            res.end(stdout);
        }
    });

})
 
var server = app.listen(8087, function () {
 
  var host = server.address().address
  var port = server.address().port
 
  console.log("应用实例，访问地址为 http://%s:%s", host, port)
 
})
